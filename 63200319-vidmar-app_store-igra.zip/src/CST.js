export const CST = {
    SCENES: {
        LOAD: "LOAD",
        MENU: "MENU",
        STAGE: "STAGE",
        UI: "UI"
    }
}